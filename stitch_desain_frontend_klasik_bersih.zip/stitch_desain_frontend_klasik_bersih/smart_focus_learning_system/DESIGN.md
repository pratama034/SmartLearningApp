---
name: Smart Focus Learning System
colors:
  surface: '#FFFFFF'
  surface-dim: '#cfd9ff'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae1ff'
  on-surface: '#0b1a3d'
  on-surface-variant: '#44464f'
  inverse-surface: '#222f53'
  inverse-on-surface: '#eef0ff'
  outline: '#757780'
  outline-variant: '#c4c6d0'
  surface-tint: '#465d92'
  primary: '#002051'
  on-primary: '#ffffff'
  primary-container: '#1d3668'
  on-primary-container: '#89a0d9'
  inverse-primary: '#b0c6ff'
  secondary: '#b61a51'
  on-secondary: '#ffffff'
  secondary-container: '#fe5585'
  on-secondary-container: '#5e0024'
  tertiary: '#002341'
  on-tertiary: '#ffffff'
  tertiary-container: '#003964'
  on-tertiary-container: '#61a5ed'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d9e2ff'
  primary-fixed-dim: '#b0c6ff'
  on-primary-fixed: '#001944'
  on-primary-fixed-variant: '#2e4578'
  secondary-fixed: '#ffd9df'
  secondary-fixed-dim: '#ffb1c0'
  on-secondary-fixed: '#3f0016'
  on-secondary-fixed-variant: '#90003b'
  tertiary-fixed: '#d1e4ff'
  tertiary-fixed-dim: '#9fcaff'
  on-tertiary-fixed: '#001d36'
  on-tertiary-fixed-variant: '#00497d'
  background: '#faf8ff'
  on-background: '#0b1a3d'
  surface-variant: '#dae1ff'
  page-bg: '#F3F4FA'
  surface-subtle: '#F6F7FC'
  border-subtle: '#DFE4F1'
  text-primary: '#1F2C4F'
  soft-blue: '#E1EAF8'
  progress-blue: '#9CC3FF'
  cream-bg: '#FBEFD9'
  cream-text: '#5E3F0C'
  status-active-bg: '#D6F0DE'
  status-active-text: '#17623A'
  status-postponed-bg: '#FCDDE6'
  status-postponed-text: '#8E1744'
  status-rest-bg: '#FDEBC8'
  status-rest-text: '#7A4B00'
typography:
  hero-clock:
    fontFamily: Montserrat
    fontSize: 56px
    fontWeight: '800'
    lineHeight: 64px
    letterSpacing: -0.02em
  hero-clock-mobile:
    fontFamily: Montserrat
    fontSize: 44px
    fontWeight: '800'
    lineHeight: 52px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Montserrat
    fontSize: 28px
    fontWeight: '800'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Montserrat
    fontSize: 22px
    fontWeight: '800'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Montserrat
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 24px
  headline-sm:
    fontFamily: Montserrat
    fontSize: 16px
    fontWeight: '700'
    lineHeight: 22px
  stat-kpi:
    fontFamily: Montserrat
    fontSize: 24px
    fontWeight: '800'
    lineHeight: 30px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Montserrat
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
  body-md:
    fontFamily: Montserrat
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Montserrat
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-md:
    fontFamily: Montserrat
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
  label-sm:
    fontFamily: Montserrat
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
  label-eyebrow:
    fontFamily: Montserrat
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.25rem
  margin: 1rem
  margin-desktop: 2rem
  space-xxs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.625rem
  space-md: 1rem
  space-lg: 1.25rem
  space-xl: 1.5rem
  space-2xl: 2rem
---

## Brand & Style

This design system is tailored specifically for Indonesian university students balancing academic rigor, group assignments, and digital distractions. The personality is disciplined, encouraging, composed, and scholarly. It establishes an atmosphere of psychological calm and structural clarity, avoiding high-stimulus neon gradients, hyper-saturated glassmorphism, or noisy decorative artifacts.

The visual style is rooted in a refined, human-crafted corporate-minimalist aesthetic. Grounded deep navy anchors top headers, primary actions, and focused timers, while tactile card surfaces rest against a muted periwinkle-tinted canvas. Information density is managed through clear grouped containers, distinct 1px hairline dividers, purposeful 2-letter monogram badging, and soft pastel pill indicators that communicate status instantly without inducing visual fatigue.

## Colors

The color palette establishes an intentional cognitive hierarchy:

- **Primary Navy (`#1D3668`)**: The cornerstone of the visual interface. Used for major headers, primary actions, active focus hero cards, and key branding elements. Conveys academic authority and serious focus.
- **Accent Crimson (`#BE2257`)**: Reserved strictly for high-priority interactive touchpoints, primary conversion buttons ("Mulai Mode Fokus"), and real-time live pulsing indicators.
- **Informational Blue (`#1F6FB4`)**: Applied to analytical charts, informative hyperlinked text, and key progress metrics.
- **Neutral Stack**: The canvas sits on `#F3F4FA`, a calm desaturated cool slate. Primary card surfaces use crisp `#FFFFFF` paired with hairline borders in `#DFE4F1`. Text hierarchy uses `#1F2C4F` for optimal reading contrast and `#56638A` for secondary labels and metadata.

### Semantic Status Pairing
Status tokens are always applied as matched pairs to ensure legibility and cognitive consistency:
- **Active / Allowed (`status-active`)**: `#D6F0DE` background with `#17623A` text for approved notifications and active study states.
- **Postponed (`status-postponed`)**: `#FCDDE6` background with `#8E1744` text for queued notifications and delayed apps.
- **Rest / Pause (`status-rest`)**: `#FDEBC8` background with `#7A4B00` text for scheduled study intervals and rest blocks.
- **Contextual Note / Tip**: `#FBEFD9` background with `#5E3F0C` text for ambient student guidance notes and study tips.
- **Active Navigation / Selection**: `#E1EAF8` background for selected tabs, active sidebar states, and summary cards.

## Typography

The typography system relies solely on **Montserrat**, leveraging its geometric clarity, structured human-editorial quality, and robust tabular numeric figures.

### Typographic Hierarchy Rules
- **Tabular Numerics**: Active focus countdowns (`hero-clock`), metric blocks (`stat-kpi`), and timetable displays must enforce `font-variant-numeric: tabular-nums` to eliminate layout jitter during active session ticks.
- **Eyebrow Headers**: Small section qualifiers use `label-eyebrow` in uppercase casing with wide `0.08em` tracking to introduce visual structure above section titles.
- **Readability**: Body copy maintains generous line-height ratios (1.4–1.5x) to maintain effortless comprehension during long academic reading sessions.

## Layout & Spacing

The layout is built upon an 8px base rhythm with specific functional step-increments (10px, 16px, 20px) to balance high touch-target comfort on mobile with organized content density on desktop.

### Layout Philosophy & Breakpoints
- **Mobile (< 768px)**: Single vertical fluid column with a fixed base width of 390px in design comps. Utilizes `margin: 1rem` (16px), a fixed dark navy header hero area, grouped card segments, a 2x2 grid for quantitative stats, and a 5-item persistent bottom navigation bar.
- **Desktop (≥ 1024px)**: Dual-column shell with a fixed 248px left navigation drawer and a fluid primary content area constrained to `max-width: 1120px` centered within `margin-desktop: 2rem` (32px). Secondary cards organize into asymmetric 2-column or 4-tile modular grids.
- **Card Padding**: Standard cards, hero blocks, and sheet dialogues enforce a consistent `space-lg` (20px / 1.25rem) internal padding.
- **Touch Ergonomics**: All interactive elements (buttons, segmented toggles, list actions) adhere to a minimum physical touch height of 44px on mobile devices.

## Elevation & Depth

Visual hierarchy is maintained through deliberate surface contrast and delicate architectural outlines, avoiding heavy shadows or glassy skeuomorphism.

- **Base Layering**: Level 0 is the muted canvas (`#F3F4FA`). Level 1 elements (cards, containers) are elevated through a solid `#FFFFFF` fill bounded by a crisp 1px `#DFE4F1` border.
- **Ambient Shadow**: Cards utilize a soft, two-layer ambient shadow: `0 2px 4px rgba(29, 54, 104, 0.03), 0 8px 16px rgba(29, 54, 104, 0.04)`. The shadow is tinted with the Primary Navy hue rather than pure neutral black, creating cohesive chromatic depth.
- **Active Focus Hero**: Inverted elevation. Sits directly at the top of the interface using a solid `#1D3668` container, commanding immediate focus and contrast against the lighter secondary cards below.
- **Modals & Overlays**: Floating dialogs use Level 2 elevation (`0 16px 32px rgba(29, 54, 104, 0.12)`) and sit atop a dimmed translucent overlay of `rgba(15, 23, 42, 0.45)`.

## Shapes

The shape system employs deliberate, tiered corner radii to differentiate structural surfaces from interactive controls and metadata badges:

- **Active Session Hero**: `18px` corner radius for primary emphasis.
- **Cards & Modals**: `16px` (`rounded-lg`) corner radius provides approachable containment for grouped information.
- **Interactive Controls**: `10px` corner radius on all primary buttons, ghost buttons, text input fields, and square app monogram badges.
- **Badges & Segmented Controls**: `999px` (fully rounded pill) for all status tags, filter chips, active navigation indicators, and toggle switches.

## Components

### Buttons
- **Primary CTA ("Mulai Mode Fokus")**: Background `#BE2257`, text `#FFFFFF`, height 46px, border-radius 10px, font weight 700. Pressed state dims to `#A11B48`.
- **Secondary / Action Navy**: Background `#1D3668`, text `#FFFFFF`, height 44px, border-radius 10px, font weight 600.
- **Ghost / Outlined**: Background `transparent`, 1px solid `#DFE4F1`, text `#1D3668`, hover fill `#F6F7FC`.
- **Destructive**: Background `transparent`, 1px solid `#BE2257`, text `#BE2257`.

### Status Pills & Badges
- Built with a height of 24px–28px, horizontal padding of 10px–12px, border-radius 999px, and `label-sm` font weight 600.
- **Active/Allowed**: Background `#D6F0DE`, text `#17623A`.
- **Postponed**: Background `#FCDDE6`, text `#8E1744`.
- **Rest/Pause**: Background `#FDEBC8`, text `#7A4B00`.
- **Informational Chip**: Background `#E1EAF8`, text `#1D3668`.

### App Monogram Badges
- Represent digital subjects and applications (e.g., "EL" for E-learning, "GK" for Grup Kelas, "KD" for Kontak Dosen).
- Container: 36px × 36px, border-radius 10px, centered bold 12px uppercase typography.
- Neutral container fill is `#E1EAF8` with `#1D3668` text, or tinted matching the specific platform color.

### Form Inputs & Controls
- **Text Inputs**: Height 44px, background `#FFFFFF`, border 1px solid `#DFE4F1`, border-radius 10px, internal padding 12px 16px. Placeholder text `#56638A`. Focus ring: 2px solid `#1D3668`.
- **Toggle Switches**: 48px width × 26px height, pill-shaped track. Active track `#1D3668`, inactive track `#DFE4F1`, circular white handle (20px). Disabled state displays a centered lock glyph when toggling is restricted.

### Card Containers
- **Standard Card**: Background `#FFFFFF`, 1px border `#DFE4F1`, border-radius 16px, padding 20px, subtle navy-tinted drop shadow.
- **Contextual Note / Tip Card**: Background `#FBEFD9`, 1px border `rgba(94, 63, 12, 0.12)`, text `#5E3F0C`, border-radius 16px, padding 16px 20px. Used for contextual guidance and study tips.
- **Active Hero Timer Card**: Background `#1D3668`, text `#FFFFFF`, border-radius 18px, padding 24px. Features tabular timer display, secondary metadata in `#9CC3FF`, and a subtle linear progress rail filled with `#9CC3FF`.

### Lists & Row Items
- List items feature 12px vertical padding, separated by 1px solid `#DFE4F1` dividers.
- Hover state on desktop transitions background to `#F6F7FC`.
- Action trails feature either chevron indicators, status pills, or switches aligned flush right.